package ten.words.teamname.Activity.Login.Register;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import ten.words.teamname.R;

public class RegisterActivity extends AppCompatActivity {

    Button done;
    EditText edt_id;
    EditText edt_pwd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        done = findViewById(R.id.register_done);
        edt_id=findViewById(R.id.register_id);
        edt_pwd=findViewById(R.id.register_pwd);

        done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String str_id = edt_id.getText().toString();
                String str_pwd = edt_pwd.getText().toString();

            }
        });
    }
}
