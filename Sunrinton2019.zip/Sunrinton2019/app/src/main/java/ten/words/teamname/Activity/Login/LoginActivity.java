package ten.words.teamname.Activity.Login;

import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import ten.words.teamname.Activity.Login.Register.RegisterActivity;
import ten.words.teamname.R;

public class LoginActivity extends AppCompatActivity {

    Button login,reg;
    EditText edt_id,edt_pwd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        login=findViewById(R.id.login_login);
        reg=findViewById(R.id.login_regis);
        edt_id=findViewById(R.id.login_id);
        edt_pwd=findViewById(R.id.login_pwd);


        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String str_id =edt_id.getText().toString();
                String str_pwd = edt_pwd.getText().toString();
                //로그인
            }
        });
        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
                startActivityForResult(intent,1234);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if (resultCode==RESULT_OK){
            if(requestCode==1234){
                //회원가입 하고 돌아왔을 때
            }
        }
    }
}
